# DREAM Android Project v8

DREAM v8 Android WebView project.

New in v8:
- Government schemes / loan guidance screen
- PMEGP, MUDRA (PMMY), and CGTMSE overview
- Clear reminder to verify current eligibility and rules on official portals
- Existing v6 features retained

Application ID: com.dream.app
Version: 4.0
