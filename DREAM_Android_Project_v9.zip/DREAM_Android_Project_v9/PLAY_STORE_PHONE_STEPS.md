# DREAM App v9 — फोनवरून पुढे जाण्याची पद्धत

1. GitHub वर खाते उघडा/लॉगिन करा.
2. New repository तयार करा: DREAM-App
3. या ZIP मधील सर्व फाइल्स repository मध्ये upload करा.
4. `main` branch वर push/commit झाल्यावर Actions मध्ये `Build DREAM AAB` workflow दिसेल.
5. Workflow पूर्ण झाल्यावर Artifacts मधून `DREAM-release-aab` डाउनलोड करता येईल.

महत्त्वाचे: हा workflow सध्या unsigned release AAB तयार करतो. Google Play वर upload करण्यासाठी पुढे signing/upload-key setup आवश्यक आहे. कोणतीही private signing key chat मध्ये पाठवू नका.
